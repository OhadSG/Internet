﻿SET IDENTITY_INSERT [dbo].[Users] ON
INSERT INTO [dbo].[Users] ([Id], [Username], [Password], [First Name], [Last Name], [Date Of Birth], [Email], [Country]) VALUES (3, N'OhadSG', N'123', N'Ohad', N'SG', N'2004-08-17', N'1782004o@gmail.com', N'Israel')
INSERT INTO [dbo].[Users] ([Id], [Username], [Password], [First Name], [Last Name], [Date Of Birth], [Email], [Country]) VALUES (1003, N'Shimiaso', N'shimihomo', N'shimi', N'refael', N'2001-06-09', N'shimiaso420@gmail.com', N'israel')
INSERT INTO [dbo].[Users] ([Id], [Username], [Password], [First Name], [Last Name], [Date Of Birth], [Email], [Country]) VALUES (1004, N'Raf.mc.dan', N'raf123', N'daniel', N'pinhasov', N'2001-11-27', N'daneilpenas@gmail.com', N'israel')
SET IDENTITY_INSERT [dbo].[Users] OFF
