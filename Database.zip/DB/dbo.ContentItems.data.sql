﻿SET IDENTITY_INSERT [dbo].[ContentItems] ON
INSERT INTO [dbo].[ContentItems] ([Id], [Title], [Description], [UserID], [Path]) VALUES (1, N'Mooma', N'Best Cow Ever!', 1, N'http://www.cows.com/Images/mooma.jpg')
INSERT INTO [dbo].[ContentItems] ([Id], [Title], [Description], [UserID], [Path]) VALUES (2, N'Shimi', N'dummy', 1, N'50iq.com')
INSERT INTO [dbo].[ContentItems] ([Id], [Title], [Description], [UserID], [Path]) VALUES (3, N'Safami', N'Tipesh', 2, N'retards.com')
SET IDENTITY_INSERT [dbo].[ContentItems] OFF
